/*
 *  Author: sherif
 */ 



#ifndef SWITCH_H_
#define SWITCH_H_

void switch_init (char port , char pin);
unsigned char switch_read(char port , char pin);

#endif /* SWITCH_H_ */