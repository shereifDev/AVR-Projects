/*
 *  Author: sherif
 */ 


#ifndef EVO_H_
#define EVO_H_

#define BUTTON_A 0
#define BUTTON_B 1
#define BUTTON_C 2
#define BUTTON_D 3
#define  RESET   4



#endif /* EVO_H_ */